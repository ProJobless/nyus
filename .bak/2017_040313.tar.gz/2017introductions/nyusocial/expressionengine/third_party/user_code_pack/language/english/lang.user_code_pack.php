<?php

$lang = array(

//----------------------------------------
// Language
//----------------------------------------

'user_code_pack_label'	=>
'User code pack',

'user_code_pack_name'	=>
'User Code Pack',

'user_code_pack_description'	=>
'Sample templates, data and functionality for the User module.',

"conflicting_emails"	=>
"Conflicting emails",

"conflicting_emails_exp"	=>
"There were conflicts with emails on your site and emails in this code pack. Please choose a different prefix to resolve the following email conflicts. %conflicting_emails%",

"conflicting_usernames"	=>
"Conflicting usernames",

"conflicting_usernames_exp"	=>
"There were conflicts with usernames on your site and usernames in this code pack. Please choose a different prefix to resolve the following username conflicts. %conflicting_usernames%",

"members_created"	=>
"Members created",

"members_created_exp"	=>
"The following members were created on your site. %members_created%",

"home_page"	=>
"Home Page",

"home_page_exp"	=>
"View the home page for this code pack here: %link%",

// END
''=>''
);
?>