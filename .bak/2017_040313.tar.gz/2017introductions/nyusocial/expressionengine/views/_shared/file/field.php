<div class="file_set <?=$set_class?>">
	<p class='filename'><img src="<?=$thumb?>" alt="<?=$alt?>"/><br /><?=$filename?></p>
	<p class='sub_filename'><a href="#" class="remove_file"><?=lang('remove_file')?></a></p>
	<p><?=$hidden?></p>
</div>

<div class="no_file js_hide">
	<p class='sub_filename'><?=$upload?></p>
	<p><?=$dropdown?></p>
</div>

<div class="modifiers js_show">
	<p class='sub_filename'><?=$upload_link?></p>
</div>