<?php 
if (isset($script_head))
{
	echo $script_head;
}

/* End of file javascript.php */
/* Location: ./themes/cp_themes/default/_shared/javascript.php */