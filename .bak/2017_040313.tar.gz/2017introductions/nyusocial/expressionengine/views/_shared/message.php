<?php foreach ($cp_messages as $cp_message_type => $cp_message):?>
	<div class="message js_hide <?=$cp_message_type?>"><?=$cp_message?></div>
<?php endforeach;

/* End of file message.php */
/* Location: ./themes/cp_themes/default/_shared/message.php */