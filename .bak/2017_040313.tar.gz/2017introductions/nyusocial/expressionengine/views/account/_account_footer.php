			</div>

			</td></tr>
			</table>
	</div>
	

	</div> <!-- contents -->
</div> <!-- mainContent -->

<?php
if ($EE_view_disable !== TRUE)
{
	$this->load->view('_shared/accessories');
	$this->load->view('_shared/footer');
}

/* End of file _account_footer.php */
/* Location: ./themes/cp_themes/default/members/_account_footer.php */